const mongoose = require("mongoose")

const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    description: {
      type: String,
      required: true,
    },
    shortDescription: {
      type: String,
      maxlength: 200,
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    compareAtPrice: {
      type: Number,
      min: 0,
    },
    sku: {
      type: String,
      unique: true,
      sparse: true,
    },
    category: {
      type: String,
      required: true,
      enum: ["eau-de-parfum", "eau-de-toilette", "custom", "gift-set", "sample"],
      index: true,
    },
    subcategory: {
      type: String,
      enum: ["unisex", "men", "women", "limited-edition"],
    },
    brand: {
      type: String,
      default: "Sugi Parfume",
    },

    // Fragrance-specific fields
    fragranceFamily: {
      type: String,
      enum: ["woody", "floral", "citrus", "oriental", "fresh", "gourmand"],
      index: true,
    },
    notes: {
      top: [String],
      heart: [String],
      base: [String],
    },
    intensity: {
      type: Number,
      min: 1,
      max: 10,
      default: 5,
    },
    longevity: {
      type: Number,
      min: 1,
      max: 10,
      default: 6,
    },
    sillage: {
      type: Number,
      min: 1,
      max: 10,
      default: 5,
    },
    season: [
      {
        type: String,
        enum: ["spring", "summer", "fall", "winter"],
      },
    ],
    occasion: [
      {
        type: String,
        enum: ["daily", "evening", "work", "special_events", "date_night", "sport"],
      },
    ],

    // Inventory
    inventory: {
      quantity: {
        type: Number,
        default: 0,
        min: 0,
      },
      trackQuantity: {
        type: Boolean,
        default: true,
      },
      allowBackorder: {
        type: Boolean,
        default: false,
      },
      lowStockThreshold: {
        type: Number,
        default: 10,
      },
    },

    // Variants (different sizes)
    variants: [
      {
        size: {
          type: String,
          required: true, // e.g., "30ml", "50ml", "100ml"
        },
        price: {
          type: Number,
          required: true,
        },
        sku: String,
        inventory: {
          quantity: {
            type: Number,
            default: 0,
          },
          trackQuantity: {
            type: Boolean,
            default: true,
          },
        },
        weight: Number, // in grams
      },
    ],

    // Media
    images: [
      {
        url: String,
        alt: String,
        isPrimary: {
          type: Boolean,
          default: false,
        },
      },
    ],
    videos: [
      {
        url: String,
        title: String,
        thumbnail: String,
      },
    ],

    // SEO
    seo: {
      title: String,
      description: String,
      keywords: [String],
      slug: {
        type: String,
        unique: true,
        sparse: true,
      },
    },

    // Status
    status: {
      type: String,
      enum: ["active", "draft", "archived", "out-of-stock"],
      default: "draft",
      index: true,
    },
    featured: {
      type: Boolean,
      default: false,
      index: true,
    },

    // Custom fragrance specific
    isCustom: {
      type: Boolean,
      default: false,
    },
    customFormula: {
      ingredients: [
        {
          name: String,
          percentage: Number,
          cost: Number,
        },
      ],
      createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      baseCost: Number,
    },

    // Analytics
    analytics: {
      views: {
        type: Number,
        default: 0,
      },
      purchases: {
        type: Number,
        default: 0,
      },
      wishlistAdds: {
        type: Number,
        default: 0,
      },
      cartAdds: {
        type: Number,
        default: 0,
      },
      lastViewed: Date,
    },

    // Reviews
    reviews: {
      averageRating: {
        type: Number,
        default: 0,
        min: 0,
        max: 5,
      },
      totalReviews: {
        type: Number,
        default: 0,
      },
      ratingDistribution: {
        1: { type: Number, default: 0 },
        2: { type: Number, default: 0 },
        3: { type: Number, default: 0 },
        4: { type: Number, default: 0 },
        5: { type: Number, default: 0 },
      },
    },

    // Shipping
    shipping: {
      weight: Number, // in grams
      dimensions: {
        length: Number,
        width: Number,
        height: Number,
      },
      shippingClass: {
        type: String,
        enum: ["standard", "fragile", "hazmat"],
        default: "fragile",
      },
    },

    // Metadata
    tags: [String],
    collections: [String],
    vendor: String,

    // Timestamps
    publishedAt: Date,
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  },
)

// Indexes for better query performance
productSchema.index({
  name: "text",
  description: "text",
  "notes.top": "text",
  "notes.heart": "text",
  "notes.base": "text",
})
productSchema.index({ price: 1 })
productSchema.index({ category: 1, status: 1 })
productSchema.index({ fragranceFamily: 1 })
productSchema.index({ featured: 1, status: 1 })
productSchema.index({ "analytics.purchases": -1 })
productSchema.index({ "reviews.averageRating": -1 })
productSchema.index({ createdAt: -1 })

// Virtual for discount percentage
productSchema.virtual("discountPercentage").get(function () {
  if (this.compareAtPrice && this.compareAtPrice > this.price) {
    return Math.round(((this.compareAtPrice - this.price) / this.compareAtPrice) * 100)
  }
  return 0
})

// Virtual for availability
productSchema.virtual("isAvailable").get(function () {
  if (this.status !== "active") return false
  if (!this.inventory.trackQuantity) return true
  return this.inventory.quantity > 0 || this.inventory.allowBackorder
})

// Virtual for low stock warning
productSchema.virtual("isLowStock").get(function () {
  if (!this.inventory.trackQuantity) return false
  return this.inventory.quantity <= this.inventory.lowStockThreshold && this.inventory.quantity > 0
})

// Virtual for primary image
productSchema.virtual("primaryImage").get(function () {
  const primary = this.images.find((img) => img.isPrimary)
  return primary || this.images[0] || null
})

// Pre-save middleware
productSchema.pre("save", function (next) {
  // Generate slug if not provided
  if (!this.seo.slug && this.name) {
    this.seo.slug = this.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
  }

  // Ensure only one primary image
  if (this.images && this.images.length > 0) {
    const primaryImages = this.images.filter((img) => img.isPrimary)
    if (primaryImages.length === 0) {
      this.images[0].isPrimary = true
    } else if (primaryImages.length > 1) {
      this.images.forEach((img, index) => {
        img.isPrimary = index === 0
      })
    }
  }

  // Set published date if status changes to active
  if (this.isModified("status") && this.status === "active" && !this.publishedAt) {
    this.publishedAt = new Date()
  }

  next()
})

// Static methods
productSchema.statics.findByCategory = function (category) {
  return this.find({ category, status: "active" })
}

productSchema.statics.findFeatured = function () {
  return this.find({ featured: true, status: "active" })
}

productSchema.statics.findByFragranceFamily = function (family) {
  return this.find({ fragranceFamily: family, status: "active" })
}

productSchema.statics.searchProducts = function (query, filters = {}) {
  const searchQuery = {
    status: "active",
    ...filters,
  }

  if (query) {
    searchQuery.$text = { $search: query }
  }

  return this.find(searchQuery)
}

// Instance methods
productSchema.methods.incrementView = function () {
  this.analytics.views += 1
  this.analytics.lastViewed = new Date()
  return this.save()
}

productSchema.methods.incrementPurchase = function () {
  this.analytics.purchases += 1
  return this.save()
}

productSchema.methods.updateInventory = function (quantity, operation = "subtract") {
  if (!this.inventory.trackQuantity) return this

  if (operation === "subtract") {
    this.inventory.quantity = Math.max(0, this.inventory.quantity - quantity)
  } else if (operation === "add") {
    this.inventory.quantity += quantity
  }

  return this.save()
}

productSchema.methods.addReview = function (rating) {
  this.reviews.totalReviews += 1
  this.reviews.ratingDistribution[rating] += 1

  // Recalculate average rating
  const totalRating = Object.keys(this.reviews.ratingDistribution).reduce((sum, star) => {
    return sum + Number.parseInt(star) * this.reviews.ratingDistribution[star]
  }, 0)

  this.reviews.averageRating = totalRating / this.reviews.totalReviews

  return this.save()
}

module.exports = mongoose.model("Product", productSchema)
