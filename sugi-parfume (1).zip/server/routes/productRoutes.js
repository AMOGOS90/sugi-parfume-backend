const express = require("express")
const router = express.Router()
const Product = require("../models/Product")
const authenticateToken = require("../middleware/auth")
const { apiLimiter } = require("../middleware/rateLimiter")
const cacheService = require("../services/CacheService")

// Apply rate limiting to all product routes
router.use(apiLimiter)

// Get all products with filtering, sorting, and pagination
router.get("/", async (req, res) => {
  try {
    const {
      page = 1,
      limit = 12,
      category,
      fragranceFamily,
      minPrice,
      maxPrice,
      search,
      sortBy = "createdAt",
      sortOrder = "desc",
      featured,
      inStock,
    } = req.query

    // Build filter object
    const filters = { status: "active" }

    if (category) filters.category = category
    if (fragranceFamily) filters.fragranceFamily = fragranceFamily
    if (featured === "true") filters.featured = true
    if (inStock === "true") {
      filters.$or = [
        { "inventory.trackQuantity": false },
        { "inventory.quantity": { $gt: 0 } },
        { "inventory.allowBackorder": true },
      ]
    }

    // Price range filter
    if (minPrice || maxPrice) {
      filters.price = {}
      if (minPrice) filters.price.$gte = Number.parseFloat(minPrice)
      if (maxPrice) filters.price.$lte = Number.parseFloat(maxPrice)
    }

    // Search filter
    if (search) {
      filters.$text = { $search: search }
    }

    // Build sort object
    const sort = {}
    sort[sortBy] = sortOrder === "desc" ? -1 : 1

    // Calculate pagination
    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    // Check cache first
    const cacheKey = `products:${JSON.stringify({ filters, sort, skip, limit })}`
    const cachedResult = await cacheService.get(cacheKey)

    if (cachedResult) {
      return res.json(cachedResult)
    }

    // Execute query
    const [products, totalCount] = await Promise.all([
      Product.find(filters)
        .sort(sort)
        .skip(skip)
        .limit(Number.parseInt(limit))
        .select("-analytics -customFormula")
        .lean(),
      Product.countDocuments(filters),
    ])

    const result = {
      success: true,
      data: products,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(totalCount / Number.parseInt(limit)),
        totalItems: totalCount,
        itemsPerPage: Number.parseInt(limit),
        hasNextPage: skip + Number.parseInt(limit) < totalCount,
        hasPrevPage: Number.parseInt(page) > 1,
      },
      filters: {
        category,
        fragranceFamily,
        minPrice,
        maxPrice,
        search,
        featured,
        inStock,
      },
    }

    // Cache the result for 5 minutes
    await cacheService.set(cacheKey, result, 300)

    res.json(result)
  } catch (error) {
    console.error("Error fetching products:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch products",
      error: error.message,
    })
  }
})

// Get featured products
router.get("/featured", async (req, res) => {
  try {
    const cacheKey = "products:featured"
    const cachedProducts = await cacheService.get(cacheKey)

    if (cachedProducts) {
      return res.json({ success: true, data: cachedProducts })
    }

    const products = await Product.findFeatured().limit(8).select("-analytics -customFormula").lean()

    await cacheService.set(cacheKey, products, 600) // Cache for 10 minutes

    res.json({
      success: true,
      data: products,
    })
  } catch (error) {
    console.error("Error fetching featured products:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch featured products",
      error: error.message,
    })
  }
})

// Get product categories and filters
router.get("/filters", async (req, res) => {
  try {
    const cacheKey = "products:filters"
    const cachedFilters = await cacheService.get(cacheKey)

    if (cachedFilters) {
      return res.json({ success: true, data: cachedFilters })
    }

    const [categories, fragranceFamilies, priceRange] = await Promise.all([
      Product.distinct("category", { status: "active" }),
      Product.distinct("fragranceFamily", { status: "active" }),
      Product.aggregate([
        { $match: { status: "active" } },
        {
          $group: {
            _id: null,
            minPrice: { $min: "$price" },
            maxPrice: { $max: "$price" },
          },
        },
      ]),
    ])

    const filters = {
      categories,
      fragranceFamilies,
      priceRange: priceRange[0] || { minPrice: 0, maxPrice: 1000 },
    }

    await cacheService.set(cacheKey, filters, 3600) // Cache for 1 hour

    res.json({
      success: true,
      data: filters,
    })
  } catch (error) {
    console.error("Error fetching filters:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch filters",
      error: error.message,
    })
  }
})

// Get single product by ID or slug
router.get("/:identifier", async (req, res) => {
  try {
    const { identifier } = req.params
    const isObjectId = /^[0-9a-fA-F]{24}$/.test(identifier)

    const cacheKey = `product:${identifier}`
    const cachedProduct = await cacheService.get(cacheKey)

    if (cachedProduct) {
      return res.json({ success: true, data: cachedProduct })
    }

    const query = isObjectId ? { _id: identifier } : { "seo.slug": identifier }
    query.status = "active"

    const product = await Product.findOne(query).select("-analytics.views -customFormula").lean()

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      })
    }

    // Increment view count (don't await to avoid blocking response)
    Product.findByIdAndUpdate(product._id, {
      $inc: { "analytics.views": 1 },
      $set: { "analytics.lastViewed": new Date() },
    }).exec()

    await cacheService.set(cacheKey, product, 1800) // Cache for 30 minutes

    res.json({
      success: true,
      data: product,
    })
  } catch (error) {
    console.error("Error fetching product:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch product",
      error: error.message,
    })
  }
})

// Get related products
router.get("/:id/related", async (req, res) => {
  try {
    const { id } = req.params
    const { limit = 4 } = req.query

    const product = await Product.findById(id).select("fragranceFamily category notes")

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      })
    }

    const cacheKey = `product:${id}:related:${limit}`
    const cachedRelated = await cacheService.get(cacheKey)

    if (cachedRelated) {
      return res.json({ success: true, data: cachedRelated })
    }

    // Find related products based on fragrance family and notes
    const allNotes = [...(product.notes.top || []), ...(product.notes.heart || []), ...(product.notes.base || [])]

    const relatedProducts = await Product.find({
      _id: { $ne: id },
      status: "active",
      $or: [
        { fragranceFamily: product.fragranceFamily },
        { category: product.category },
        {
          $or: [
            { "notes.top": { $in: allNotes } },
            { "notes.heart": { $in: allNotes } },
            { "notes.base": { $in: allNotes } },
          ],
        },
      ],
    })
      .limit(Number.parseInt(limit))
      .select("-analytics -customFormula")
      .lean()

    await cacheService.set(cacheKey, relatedProducts, 1800) // Cache for 30 minutes

    res.json({
      success: true,
      data: relatedProducts,
    })
  } catch (error) {
    console.error("Error fetching related products:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch related products",
      error: error.message,
    })
  }
})

// Search products with advanced filters
router.post("/search", async (req, res) => {
  try {
    const { query, filters = {}, sort = { createdAt: -1 }, page = 1, limit = 12 } = req.body

    const searchFilters = {
      status: "active",
      ...filters,
    }

    if (query) {
      searchFilters.$text = { $search: query }
    }

    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const [products, totalCount] = await Promise.all([
      Product.find(searchFilters)
        .sort(sort)
        .skip(skip)
        .limit(Number.parseInt(limit))
        .select("-analytics -customFormula")
        .lean(),
      Product.countDocuments(searchFilters),
    ])

    res.json({
      success: true,
      data: products,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(totalCount / Number.parseInt(limit)),
        totalItems: totalCount,
        itemsPerPage: Number.parseInt(limit),
      },
      query,
      filters,
    })
  } catch (error) {
    console.error("Error searching products:", error)
    res.status(500).json({
      success: false,
      message: "Failed to search products",
      error: error.message,
    })
  }
})

// Create custom fragrance
router.post("/custom", authenticateToken, async (req, res) => {
  try {
    const { name, description, notes, intensity, ingredients, size = "50ml" } = req.body

    const userId = req.user.userId

    // Calculate price based on ingredients
    const baseCost = 120
    const ingredientCost = ingredients.reduce((total, ingredient) => {
      return total + (ingredient.cost || 0)
    }, 0)
    const intensityMultiplier = 1 + (intensity - 50) / 100
    const finalPrice = Math.round((baseCost + ingredientCost) * intensityMultiplier)

    const customProduct = new Product({
      name: name || `Custom Fragrance by ${req.user.name}`,
      description: description || "A unique custom fragrance created just for you",
      price: finalPrice,
      category: "custom",
      fragranceFamily: "custom",
      notes: {
        top: notes.top || [],
        heart: notes.heart || [],
        base: notes.base || [],
      },
      intensity,
      isCustom: true,
      customFormula: {
        ingredients,
        createdBy: userId,
        baseCost,
      },
      variants: [
        {
          size,
          price: finalPrice,
          sku: `CUSTOM_${Date.now()}`,
          inventory: {
            quantity: 1,
            trackQuantity: true,
          },
        },
      ],
      status: "active",
      createdBy: userId,
    })

    await customProduct.save()

    res.status(201).json({
      success: true,
      data: customProduct,
      message: "Custom fragrance created successfully",
    })
  } catch (error) {
    console.error("Error creating custom fragrance:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create custom fragrance",
      error: error.message,
    })
  }
})

// Get fragrance ingredients for custom builder
router.get("/ingredients/all", async (req, res) => {
  try {
    const cacheKey = "fragrance:ingredients"
    const cachedIngredients = await cacheService.get(cacheKey)

    if (cachedIngredients) {
      return res.json({ success: true, data: cachedIngredients })
    }

    const ingredients = {
      top: [
        { id: 1, name: "Bergamot", description: "Citrusy and fresh", price: 15, family: "citrus" },
        { id: 2, name: "Lemon", description: "Bright and zesty", price: 12, family: "citrus" },
        { id: 3, name: "Pink Pepper", description: "Spicy and warm", price: 18, family: "spicy" },
        { id: 4, name: "Yuzu", description: "Japanese citrus", price: 20, family: "citrus" },
        { id: 5, name: "Lavender", description: "Floral and calming", price: 16, family: "floral" },
        { id: 6, name: "Mint", description: "Cool and refreshing", price: 14, family: "fresh" },
      ],
      heart: [
        { id: 7, name: "Japanese Cedar", description: "Woody and serene", price: 25, family: "woody" },
        { id: 8, name: "Rose", description: "Classic and romantic", price: 30, family: "floral" },
        { id: 9, name: "Jasmine", description: "Exotic and intoxicating", price: 28, family: "floral" },
        { id: 10, name: "Hinoki", description: "Sacred Japanese wood", price: 35, family: "woody" },
        { id: 11, name: "Pine", description: "Fresh forest scent", price: 22, family: "woody" },
        { id: 12, name: "Geranium", description: "Green and rosy", price: 24, family: "floral" },
      ],
      base: [
        { id: 13, name: "Sandalwood", description: "Creamy and smooth", price: 40, family: "woody" },
        { id: 14, name: "Vetiver", description: "Earthy and grounding", price: 35, family: "woody" },
        { id: 15, name: "Amber", description: "Warm and resinous", price: 45, family: "oriental" },
        { id: 16, name: "Musk", description: "Sensual and lasting", price: 50, family: "musky" },
        { id: 17, name: "Vanilla", description: "Sweet and comforting", price: 30, family: "gourmand" },
        { id: 18, name: "Patchouli", description: "Earthy and mysterious", price: 32, family: "woody" },
      ],
    }

    await cacheService.set(cacheKey, ingredients, 7200) // Cache for 2 hours

    res.json({
      success: true,
      data: ingredients,
    })
  } catch (error) {
    console.error("Error fetching ingredients:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch ingredients",
      error: error.message,
    })
  }
})

// Calculate custom fragrance price
router.post("/calculate-price", async (req, res) => {
  try {
    const { ingredients, intensity = 50, size = "50ml" } = req.body

    const basePrices = {
      "30ml": 100,
      "50ml": 120,
      "100ml": 180,
    }

    const basePrice = basePrices[size] || basePrices["50ml"]
    const ingredientCost = ingredients.reduce((total, ingredient) => {
      return total + (ingredient.price || 0)
    }, 0)

    const intensityMultiplier = 1 + (intensity - 50) / 100
    const finalPrice = Math.round((basePrice + ingredientCost) * intensityMultiplier)

    res.json({
      success: true,
      data: {
        basePrice,
        ingredientCost,
        intensityMultiplier,
        finalPrice,
        breakdown: {
          base: basePrice,
          ingredients: ingredientCost,
          intensityAdjustment: Math.round((basePrice + ingredientCost) * (intensityMultiplier - 1)),
        },
      },
    })
  } catch (error) {
    console.error("Error calculating price:", error)
    res.status(500).json({
      success: false,
      message: "Failed to calculate price",
      error: error.message,
    })
  }
})

// Admin routes (require authentication and admin role)
router.use(authenticateToken)

// Create new product (Admin only)
router.post("/", async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Admin access required",
      })
    }

    const productData = {
      ...req.body,
      createdBy: req.user.userId,
    }

    const product = new Product(productData)
    await product.save()

    // Invalidate relevant caches
    await cacheService.del("products:featured")
    await cacheService.del("products:filters")

    res.status(201).json({
      success: true,
      data: product,
      message: "Product created successfully",
    })
  } catch (error) {
    console.error("Error creating product:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create product",
      error: error.message,
    })
  }
})

// Update product (Admin only)
router.put("/:id", async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Admin access required",
      })
    }

    const { id } = req.params
    const updateData = {
      ...req.body,
      updatedBy: req.user.userId,
    }

    const product = await Product.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    })

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      })
    }

    // Invalidate caches
    await cacheService.del(`product:${id}`)
    await cacheService.del(`product:${product.seo.slug}`)
    await cacheService.del("products:featured")
    await cacheService.del("products:filters")

    res.json({
      success: true,
      data: product,
      message: "Product updated successfully",
    })
  } catch (error) {
    console.error("Error updating product:", error)
    res.status(500).json({
      success: false,
      message: "Failed to update product",
      error: error.message,
    })
  }
})

// Delete product (Admin only)
router.delete("/:id", async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Admin access required",
      })
    }

    const { id } = req.params

    const product = await Product.findByIdAndUpdate(
      id,
      { status: "archived", updatedBy: req.user.userId },
      { new: true },
    )

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      })
    }

    // Invalidate caches
    await cacheService.del(`product:${id}`)
    await cacheService.del(`product:${product.seo.slug}`)
    await cacheService.del("products:featured")
    await cacheService.del("products:filters")

    res.json({
      success: true,
      message: "Product archived successfully",
    })
  } catch (error) {
    console.error("Error deleting product:", error)
    res.status(500).json({
      success: false,
      message: "Failed to delete product",
      error: error.message,
    })
  }
})

module.exports = router
